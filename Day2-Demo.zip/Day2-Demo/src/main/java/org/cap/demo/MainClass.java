package org.cap.demo;

public class MainClass {

	public static void greetings(){
		System.out.println("Hey! Good AfterNoon!");
	}
	
	public static void main(String[] args) {
		greetings();
	}

}
