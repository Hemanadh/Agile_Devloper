package org.cap.demo;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

public class SampleTest {

	@Category(ReportCategory.class)
	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
