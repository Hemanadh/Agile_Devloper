package org.cap.demo;

public interface LoginCategory {

}
