package org.cap.demo;

public interface ReportCategory {

}
